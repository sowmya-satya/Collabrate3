package com.mindtree.comicsueprhero;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ComicsuperheroApplicationTests {

	@Test
	void contextLoads() {
	}

}
