package com.mindtree.comicsuperhero.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;

import com.mindtree.comicsuperhero.entity.Comic;
import com.mindtree.comicsuperhero.service.ComicService;

@Controller
public class AppController {

	@Autowired
	private ComicService comicService;

	@RequestMapping("/")
	public String home() {
		return "home";
	}

	@RequestMapping("/addComic")
	public String addDetails(@RequestBody Comic comic, Model model) {
		Comic comicDetails = comicService.addDetails(comic);
		model.addAttribute("comic", comicDetails);
		return "comicaddedpage";
	}
}
