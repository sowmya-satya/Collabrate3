package com.mindtree.comicsuperhero.entity;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.Id;
import javax.persistence.ManyToOne;

@Entity
public class Power {

	@Id
	private int powerId;
	private String powerName;
	private int damage;
	@ManyToOne(cascade = CascadeType.ALL)
	private SuperHero superHero;

	public Power() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Power(int powerId, String powerName, int damage, SuperHero superHero) {
		super();
		this.powerId = powerId;
		this.powerName = powerName;
		this.damage = damage;
		this.superHero = superHero;
	}

	public int getPowerId() {
		return powerId;
	}

	public void setPowerId(int powerId) {
		this.powerId = powerId;
	}

	public String getPowerName() {
		return powerName;
	}

	public void setPowerName(String powerName) {
		this.powerName = powerName;
	}

	public int getDamage() {
		return damage;
	}

	public void setDamage(int damage) {
		this.damage = damage;
	}

	public SuperHero getSuperHero() {
		return superHero;
	}

	public void setSuperHero(SuperHero superHero) {
		this.superHero = superHero;
	}

	@Override
	public String toString() {
		return "Power [powerId=" + powerId + ", powerName=" + powerName + ", damage=" + damage + ", superHero="
				+ superHero + "]";
	}

}
