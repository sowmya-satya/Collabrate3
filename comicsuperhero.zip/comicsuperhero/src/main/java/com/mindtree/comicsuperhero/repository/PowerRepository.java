package com.mindtree.comicsuperhero.repository;

import org.springframework.stereotype.Repository;

@Repository
public class PowerRepository {

}
