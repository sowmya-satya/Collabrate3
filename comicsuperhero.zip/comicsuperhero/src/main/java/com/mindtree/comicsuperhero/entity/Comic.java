package com.mindtree.comicsuperhero.entity;

import java.util.Set;

import javax.persistence.CascadeType;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.OneToMany;

@Entity
public class Comic {

	@Id
	@GeneratedValue(strategy = GenerationType.IDENTITY)
	private int comicId;
	private String comicName;
	private String universe;
	@OneToMany(cascade = CascadeType.ALL, mappedBy = "comic")
	private Set<SuperHero> superHero;

	public Comic() {
		super();
		// TODO Auto-generated constructor stub
	}

	public Comic(int comicId, String comicName, String universe, Set<SuperHero> superHero) {
		super();
		this.comicId = comicId;
		this.comicName = comicName;
		this.universe = universe;
		this.superHero = superHero;
	}

	public int getComicId() {
		return comicId;
	}

	public void setComicId(int comicId) {
		this.comicId = comicId;
	}

	public String getComicName() {
		return comicName;
	}

	public void setComicName(String comicName) {
		this.comicName = comicName;
	}

	public String getUniverse() {
		return universe;
	}

	public void setUniverse(String universe) {
		this.universe = universe;
	}

	public Set<SuperHero> getSuperHero() {
		return superHero;
	}

	public void setSuperHero(Set<SuperHero> superHero) {
		this.superHero = superHero;
	}

	@Override
	public String toString() {
		return "Comic [comicId=" + comicId + ", comicName=" + comicName + ", universe=" + universe + ", superHero="
				+ superHero + "]";
	}

}
