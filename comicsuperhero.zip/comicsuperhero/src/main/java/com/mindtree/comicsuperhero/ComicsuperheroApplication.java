package com.mindtree.comicsuperhero;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class ComicsuperheroApplication {

	public static void main(String[] args) {
		SpringApplication.run(ComicsuperheroApplication.class, args);
	}

}
