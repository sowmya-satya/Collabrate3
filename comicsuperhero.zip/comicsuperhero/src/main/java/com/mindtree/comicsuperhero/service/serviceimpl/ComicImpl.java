package com.mindtree.comicsuperhero.service.serviceimpl;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.mindtree.comicsuperhero.entity.Comic;
import com.mindtree.comicsuperhero.repository.ComicRepository;
import com.mindtree.comicsuperhero.repository.PowerRepository;
import com.mindtree.comicsuperhero.service.ComicService;

@Service
public class ComicImpl implements ComicService {

	@Autowired
	private PowerRepository powerRepository;
	@Autowired
	private SuperHeroRepository superHeroRepository;
	@Autowired
	private ComicRepository comicRepository;
	@Override
	public Comic addDetails(Comic comic) {

		return null;
	}

}
