package com.mindtree.comicsuperhero.service;

import com.mindtree.comicsuperhero.entity.Comic;

public interface ComicService {

	Comic addDetails(Comic comic);

}
